# Fourier IFA API - Universal Core

Este proyecto implementa la infraestructura universal del motor matemático **Fourier IFA (Inteligencia Fractal Armónica)**. Actúa como una capa previa de procesamiento de datos secuenciales a alta velocidad y bajo consumo, sintonizando y filtrando el ruido caótico a una frecuencia exacta de **7.25 Hz**.

El sistema es completamente agnóstico al dominio de datos de entrada: procesa con la misma eficacia series temporales financieras (como la volatilidad de Bitcoin), logs de vibración industrial, telemetría logística, o flujos secuenciales para modelos de Inteligencia Artificial.

## Estructura del Proyecto

- `main.py`: Código principal que contiene la aplicación FastAPI, los esquemas de datos `UniversalDataPayload` y `UniversalIFAResponse`, la lógica del filtro matemático Fourier IFA (`apply_fourier_ifa_filter`), y los endpoints de purificación y salud.
- `requirements.txt`: Dependencias del sistema (FastAPI, Uvicorn, NumPy, Requests).
- `test_client.py`: Script cliente para la validación automatizada de dos escenarios de simulación distintos (Financiero e Industrial).

## Requisitos Previos

Necesitas tener Python instalado en tu máquina. Se recomienda usar un entorno virtual.

## Instalación y Configuración

1. Instala las dependencias necesarias ejecutando el siguiente comando:
   ```bash
   pip install -r requirements.txt
   ```

2. Ejecuta el servidor FastAPI de forma local:
   ```bash
   uvicorn main:app --reload
   ```
   El servidor estará disponible en [http://127.0.0.1:8000](http://127.0.0.1:8000).

3. Puedes abrir tu navegador y consultar la documentación interactiva (Swagger UI) en:
   [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)

## Ejecución de Pruebas

Para validar los escenarios de purificación de datos (Bitcoin y vibración industrial), ejecuta en otra consola:
```bash
python test_client.py
```
El script generará señales de prueba ruidosas, consultará a la API universal y mostrará los resultados de purificación junto a la métrica de ganancia de eficiencia de cómputo.
